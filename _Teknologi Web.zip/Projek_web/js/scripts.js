// Toggle dark mode
document.addEventListener('DOMContentLoaded', function () {
    // Create toggle button
    const toggleDarkMode = document.createElement('button');
    toggleDarkMode.classList.add('toggle-dark-mode');

    const lightModeImg = 'images/light-mode.png'; // Path to light mode image
    const darkModeImg = 'images/dark-mode.png'; // Path to dark mode image

    const imgElement = document.createElement('img');
    imgElement.src = lightModeImg;
    toggleDarkMode.appendChild(imgElement);

    document.body.appendChild(toggleDarkMode);

    // Toggle dark mode functionality
    toggleDarkMode.addEventListener('click', function () {
        document.body.classList.toggle('dark-mode');

        // Change the image based on mode
        if (document.body.classList.contains('dark-mode')) {
            imgElement.src = darkModeImg;
        } else {
            imgElement.src = lightModeImg;
        }
    });

    // Add dark mode styles dynamically
    const darkModeStyles = document.createElement('style');
    darkModeStyles.textContent = `
        .dark-mode {
            background-color: #333;
            color: black;
        }

        .dark-mode header {
            background-color: #222;
        }

        .dark-mode footer {
            background-color: #222;
        }

        .dark-mode form {
            background-color: #444;
            color: white;
        }

        .dark-mode form input, .dark-mode form textarea {
            background-color: #555;
            color: white;
            border: 1px solid #777;
        }

        .dark-mode form button {
            background-color: #526b82;
        }
    `;
    document.head.appendChild(darkModeStyles);
});
