Nama	: Wahyu Ferdy Irawan
NIM	: 5312422049

Tema website yang saya pilih adalah website artikel
fitur yang saya sertakan pada website saya mencakup:
- tampilan desain yang sederhana dan mudah dimengerti
- tombol navigasi yang mempermudah untuk perpindahan page ke page lain
- fitur dark mode yang dapat digunakan dengan menekan tombol lampu pada bagian kanan bawah website
- artikel dengan model statis, sehingga desain tiap laman artikel dapat dimodifikasi sesuai preferensi

